package edu.orangecoastcollege.cs273.jalmashashswed.occofficehours;

import java.lang.reflect.Array;

/**
 * Created by swedj_000 on 11/27/2017.
 */

public class Instructor {

    private long mId;
    private String mLastName;
    private String mFirstName;
    private String mEmail;
    private String mOfficeRoom;
    private String mOfficeHours;
    private String mDepartment;

    public Instructor(long id, String lastName, String firstName, String email, String officeRoom, String officeHours, String department) {
        mId = id;
        mLastName = lastName;
        mFirstName = firstName;
        mEmail = email;
        mOfficeRoom = officeRoom;
        mOfficeHours = officeHours;
        mDepartment = department;
    }

    public Instructor(String lastName, String firstName, String email, String officeRoom, String officeHours, String department) {
      this(-1,lastName,firstName,email,officeRoom,officeHours,department);
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public String getLastName() {
        return mLastName;
    }

    public void setLastName(String lastName) {
        mLastName = lastName;
    }

    public String getFirstName() {
        return mFirstName;
    }

    public void setFirstName(String firstName) {
        mFirstName = firstName;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getOfficeRoom() {
        return mOfficeRoom;
    }

    public void setOfficeRoom(String officeRoom) {
        mOfficeRoom = officeRoom;
    }

    public String getOfficeHours() {
        return mOfficeHours;
    }

    public void setOfficeHours(String officeHours) {
        mOfficeHours = officeHours;
    }

    public String getDepartment() {
        return mDepartment;
    }

    public void setDepartment(String department) {
        mDepartment = department;
    }

    public String toString() {
        return "Instructor{" +
                "Id=" + mId +
                ", LastName='" + mLastName + '\'' +
                ", FirstName='" + mFirstName + '\'' +
                ", Email='" + mEmail + '\'' +
                ", OfficeRoom='"+ mOfficeRoom+'\''+
                ", OfficeHours='"+ mOfficeHours+'\''+
                ", Department='"+ mDepartment+'\''+
                '}';
    }
}
