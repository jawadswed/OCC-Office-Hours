package edu.orangecoastcollege.cs273.jalmashashswed.occofficehours;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class SearchActivity extends AppCompatActivity {


    private EditText nameSearchEditText;
    private EditText departmentSearchEditText;
    private EditText classSearchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        nameSearchEditText = (EditText) findViewById(R.id.nameSearchEditText);
        departmentSearchEditText = (EditText) findViewById(R.id.departmentSearchEditText);
        classSearchEditText = (EditText) findViewById(R.id.classSearchEditText);



    }
}
